package com.epam.ConstCost;

public class InvalidMaterialSelect extends  Exception{
    public InvalidMaterialSelect(){
        super("Invalid material selected ");
    }
}